<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/app.css') }}">
</head>

<body>
    <div id="error">

        <div class="container text-center pt-32">
            <img src="{{ asset('assets/images/sarpras_logo.png') }}" style="width: 60%; height: auto" alt="" srcset="">
            <h3>500 - Terjadi Kesalahan.</h3>
            <a href="{{ url('home') }}" class='btn btn-primary'>Go Home</a>
        </div>
    </div>
</body>

</html>